import pymysql
import json

#문자출력
def syso(*p):
    s = ""
    type(p)
    for param in p:
        s += str(param)
    print(s + "\r\n")

def sout(*p):
    return syso(*p);

def sysout(*p):
    return syso(*p);

# 운영DB 접속
def getServerDBConnection(id,password):
    dbconn = None

    while dbconn == None:
        dbconn = None
        user_id = id
        pass_wd = password

        try:
            dbconn = pymysql.connect(host='db-t9b4.cdb.ntruss.com', port=3306, user=user_id, password=pass_wd, db='cwaidata', charset='utf8')
        except Exception as ex:

            if ex.args[0] == 1045:
                return -1
            else:
                return -2

        if dbconn != None:

            print('## 운영 데이터베이스 접속 성공!')
        else:
            dbconn = None
        return dbconn

# 개발DB 접속
def getDevDBConnection(id,password):

    dbconn = None

    while dbconn == None:
        dbconn = None
        user_id = id
        pass_wd = password

        try:
            dbconn = pymysql.connect(host='db-svmk.cdb.ntruss.com', port=3306, user=user_id, password=pass_wd, db='cwaidata', charset='utf8')
        except Exception as ex:

            if ex.args[0] == 1045:
                return -1
            else:
                return -2

        if dbconn != None:

            print('## 개발 데이터베이스 접속 성공!')
        else:
            dbconn = None
        return dbconn

#DB접속
def getServerConn(serverType="dev",id = None,password = None):

    if id == None :
        return -1
    if password == None :
        return -2
    conn = None
    if serverType.lower() == "dev" or serverType == "2":
        conn = getDevDBConnection(id,password)
    elif serverType.lower() == "prd" or serverType == "1":
        conn = getServerDBConnection(id,password)
    return conn

#DB 데이터 추출 (2중배열)
def getDatabaseData(sql, serverType="dev",id=None,password=None):
    conn = getServerConn(serverType,id,password)
    curs = conn.cursor()
    curs.execute(sql)
    rows = curs.fetchall()
    return rows

#DB 데이터 엑셀화
def createExcelBySql(sql, fileName, serverType = "dev", id =None, password=None):
    rows = getDatabaseData(sql, serverType,id,password)
    wb = openpyxl.Workbook()
    ws = wb.active  # 활성화 시트
    row_index = 1
    for row in rows:
        for col in range(0, len(row)):
            # print(row[col], end=' ')
            ws.cell(row=row_index, column=col + 1).value = row[col]
        row_index = row_index + 1
        # print()
    wb.save(fileName)
    wb.close()

# excel to dict
#args >>  { "filepath":"파일경로", "sheetnum":0, "maxcol":5, "maxrow":90, "startrow":1, "selcol":[1,2,3,5]}
# default
# - maxcol : auto
# - sheetnum : 0
# - maxrow : auto
# - startrow : 1
# - selcol : all
def excelToList(args):

    filepath = ""

    if "filepath" in args:
        filepath = args["filepath"]

    wb = openpyxl.load_workbook(filename=filepath)
    sn = wb.sheetnames

    sheetnum = 0;
    # sheetNumber 옵션 적용
    if "sheetnum" in args:
        sheetnum = args["sheetnum"]

    selcol = -1
    if "selcol" in args:
        selcol = args["selcol"]

    count = 0
    st = wb[sn[sheetnum]]

    # 사용 변수2
    maxcol = st.max_column
    maxrow = st.max_row
    startrow = 1

    # 옵션 적용
    if "maxcol" in args:
        maxcol = args["maxcol"]
    if "maxrow" in args:
        maxrow = args["maxrow"]
    if "startrow" in args:
        startrow = args["startrow"]

    rlist = []
    for i in st.iter_rows(min_row=startrow, max_col=maxcol, max_row=maxrow):
        count = count + 1

        t = [None]*maxcol
        #딕셔너리 만들고 그걸 추가하는 형식으로 가야한다.
        for j in range(0,maxcol):
            if selcol != -1:
                if j not in selcol:
                    continue

            t[j] = i[j].value

        rlist.append(t);

    return rlist

#list to text file (only string)
# cCount is zero number ( 속성적용시 맨윗줄 0 으로 처리하는 거 자동처리)
def listToTxt(path, cCount=0, stringArr = []):
    if type(cCount).__name__ == 'int' and type(stringArr).__name__ == 'list':

        f = open(path, 'w', encoding="utf-8")
        top_line = ""
        for i in range(0,cCount):
            if i == cCount-1:
                top_line += '0'
                break
            top_line += '0'+'\t'

        #맨 윗줄 쓰기
        f.write(top_line+"\n")

        #한줄한줄 쓰기
        for oneline in stringArr:
            f.write(oneline+'\n')

    if type(stringArr) is str:
        f = open(path, 'w', encoding="utf-8")

        if cCount != 0:
            top_line = ""
            for i in range(0,cCount):
                if i == cCount-1:
                    top_line += '0'
                    break
                top_line += '0'+'\t'
            f.write(top_line+"\n")
        f.write(stringArr + "\n")

#문자열 합치기
def string(*p):
    s = ""
    for param in p:
        s += str(param)
    return s

#dict -> 속성단위마다 탭으로 한줄로 표현
def autoTab(i=0,arr={}):
    if type(arr) is dict:

        string = ""
        if( i != 0):
            string = str(i)+"\t"

        for keyMap in enumerate(arr.keys()):

            if  keyMap[0] == len(arr.keys()):
                string += arr[keyMap[1]] + "\t"
                continue

            string += str(arr[keyMap[1]])+"\t"

        return string
    else:
        return None

def jsonToFile(path, json_object):
    with open(path, 'w', encoding='utf-8') as jsonFile :
        txt = json.dumps(json_object, ensure_ascii=False, indent="\t")
        jsonFile.write(txt)